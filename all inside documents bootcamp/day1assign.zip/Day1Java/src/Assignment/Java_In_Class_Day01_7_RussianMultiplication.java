package Assignment;
import java.util.*;
public class Java_In_Class_Day01_7_RussianMultiplication{
    public static int getProduct(int num1, int num2)
    {
        if(num1 < 0 || num2 <0)
        return -1;
        
        int prod = 0;
        boolean isFirst = true;
        while (num1>0)
        {
            if (num1 % 2 !=0)
           {
            prod += num2;
            if(isFirst){
               // int res;
                res += num2;
                isFirst = false;
                       }
            else{
                res += num2;
                }
            }
            num1 /= 2;
            num2 *= 2;
        }
            res += prod;
            res/=2;
            return res;
        }
             static int res;
            public static void main(String[] args){
                System.out.println(getProduct(11,12));
                                                  }
}