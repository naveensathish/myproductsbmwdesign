package Assignment;
public class Java_In_Class_Day_01_6_CountLeftTruncatablePrimes {
		
		
		public static int countoftruncatedprime(int start,int end){
	        if(start > end)
				return -1;
			if(start < 0 || end < 0)
				return -2;
			if(start == 0 || end == 0)
				return -3;
	        int count = 0;
	        for(int i=start;i<=end;i++){
	            if(checktruncatedprime(i)==true)
	                count++;
	        }
	        return count;
	    }
	    public static boolean checktruncatedprime(int num){
	        String s= String.valueOf(num);
	        if(s.contains("0")){
	            return false;
	        }
	        int l1= s.length();
	        for(int i=0;i<l1;i++){
	            int n1=Integer.parseInt(s.substring(i,l1));
	            if(checkPrime(n1)==true){
	                continue;
	            }
	            else{
	                return false;
	            }
	            
	        }
	        return true;
	    }
	    public static boolean checkPrime(int n){
	        if (n <= 1)
	            return false;
	        else if (n == 2)
	            return true;
	        else if (n % 2 == 0)
	            return false;
	        for (int i = 3; i <= Math.sqrt(n); i += 2)
	        {
	            if (n % i == 0)
	                return false;
	        }
	        return true;
	    }
	    
		public static void main(String[] args) {
			System.out.println(countoftruncatedprime(1,200));
		}
	
	}