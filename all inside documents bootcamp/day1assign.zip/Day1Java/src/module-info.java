module Day1Java {
}