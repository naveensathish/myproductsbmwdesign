package day4guid;

class Student{

	private long studentId;
	private String studentName;
	private double marks1,marks2,marks3;

	private static long counter = 1000;

	public Student(){
		this.studentId = counter++;
	}
	public Student(String studentName,double marks1,double marks2,double marks3){
		this.studentId = counter++;
		this.studentName = studentName;
		this.marks1 = marks1;
		this.marks2 = marks2;
		this.marks3 = marks3;
	}

	public long getStudentId() {
		return studentId;
	}
	public double getTotalMarks(){
		return marks1+marks2+marks3;
	}
	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public double getMarks1() {
		return marks1;
	}

	public void setMarks1(double marks1) {
		this.marks1 = marks1;
	}

	public double getMarks2() {
		return marks2;
	}

	public void setMarks2(double marks2) {
		this.marks2 = marks2;
	}

	public double getMarks3() {
		return marks3;
	}

	public void setMarks3(double marks3) {
		this.marks3 = marks3;
	}

	public static long getCounter() {
		return counter;
	}

	public static void setCounter(long counter) {
		Student.counter = counter;
	}


	@Override
	public String toString() {
		return "Student [marks1=" + marks1 + ", marks2=" + marks2 + ", marks3=" + marks3 + ", studentId=" + studentId
				+ ", studentName=" + studentName + "]";
	}


}
class Result {
	public static String resultCalculator(Student student){
		if(student.getMarks1()<40 || student.getMarks2()<40 || student.getMarks3()<40)
			return "Fail";

		double total = student.getTotalMarks();
		double percentage = total*100/300;
		if(percentage>=70)return "A";
		else if(percentage>=55 && percentage<70)return "B";
		else return "C";
	}
}
public class StudentGrades{
	public static void main(String[] args) {
		Student s1 = new Student("vijay ",66,60,81);
		Student s2 = new Student("naveen",86,91,76);

		Student s3 = new Student();
		s3.setStudentName("barath");
		
		s3.setMarks1(85);
		s3.setMarks2(76);
		s3.setMarks3(65);

		System.out.println(s1.getStudentName() + "  "+ Result.resultCalculator(s1));
		System.out.println(s2.getStudentName() + "  "+ Result.resultCalculator(s2));
		System.out.println(s3.getStudentName() + "  "+ Result.resultCalculator(s3));
	}
}