package day4guid;

public class TalentSprint {

	private double basePay;
	private int hoursWorked;
	
	public TalentSprint() {
		
	}
	
public TalentSprint(double basePay, int hoursWorked) {
		this.basePay=basePay;
		this.hoursWorked=hoursWorked;
	}
public String computeSalary(double basePay, int hoursWorked ) {
        this.basePay=basePay;
        this.hoursWorked=hoursWorked;
        if(this.basePay < 8.00 || this.hoursWorked > 60) {
        	return "error";
        }
        if(this.hoursWorked > 40) {
        	double payVal = 40 + this.basePay;
        	double payy = this.basePay*(this.hoursWorked%40)*1.5;
        	return Double.toString(payVal + payy);
        }
        else {
        	return Double.toString(this.hoursWorked * this.basePay);
        }
}
        
		public static void main(String[] args) {
			TalentSprint employee=new TalentSprint();

			String Employee1=employee.computeSalary(7.50,35);
			System.out.println(Employee1);
			String Employee2=employee.computeSalary(8.20,47);
			System.out.println(Employee2);
			String Employee3=employee.computeSalary(10.00,3);
			System.out.println(Employee3);
			

		}

}

